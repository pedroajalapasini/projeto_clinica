<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./estilos.css">
    <title>Turnos</title>
</head>
<body>
<?php
        include ('header.php');
    ?>
    <div  id="contenedor_turno">
                <h1>Solicite tu turno:</h1>
            <form action="enviar_turno.php" method="post">
                <h3 class="contacto_turno">Nombre: <input type="text" name="nombre_turno" class="n_turno" required></h3>
                <h3 class="contacto_turno">Email: <input type="email" name="email_turno"  class="e_turno" required></h3>
                <h3 class="contacto_turno">Obra Social: <input type="text" name="os_turno" class="os_turno" required></h3>
                <h3 class="contacto_turno">Especialidad: <input type="text" name="especialidad_turno"  class="esp_turno"required></h3>
                <h3 class="contacto_turno">Fecha: <input type="date" name="fecha_turno" class="fecha_turno" required></h3>
                <h3 class="contacto_turno">Horario: <input type="time" name="horario_turno"  class="hora_turno"required></h3>
                
                <input type="submit" value="Enviar" id="b_enviar_turno" style="font-size:10pt;">
            </form>
            </div>
            <?php
    include ('footer.php');
    ?>
</body>
</html>