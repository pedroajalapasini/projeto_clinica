<?php
$nombre_turno=$_POST['nombre_turno'];
$email_turno=$_POST['email_turno'];
$os_turno=$_POST['os_turno'];
$especialidad_turno=$_POST['especialidad_turno'];
$fecha_turno=$_POST['fecha_turno'];
$horario_turno=$_POST['horario_turno'];


$conex_turno = mysqli_connect("localhost", "root", "", "consultorio_ramos") or exit ('no fue posible conectar a la base de datos');
mysqli_query($conex_turno,"INSERT INTO turnos VALUES (DEFAULT,'$nombre_turno','$email_turno','$os_turno','$especialidad_turno','$fecha_turno','$horario_turno')");

header("Location: turnos.php");

mysqli_close($conex_turno);
?>