
        <div class="btn_pie">
            <ul>
                <li><a href="turnos.php">Turnos</a></li>
                <li><a href="contacto.php">Contacto</a></li>
                <li><a href="institucional.php">Institucional</a></li>
            </ul>
        </div>
        <div class="pie_pag">
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore, autem! Lorem ipsum dolor sit amet
                consectetur adipisicing elit. .</p>
        </div>
        <div class="creditos">
            <h5>Desarrollado por Iago Ramos.</h5>
        </div>