<header>
        <div class="img_marca">
            <img src="./img/logo.png" alt="">
        </div>
        <div class="btn_principal">
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li><li><a href="nosotros.php?medico=I-R">Nosotros</a></li>
                    <li><a href="servicios.php">Servicios</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                </ul>
            </nav>
        </div>
    </header>