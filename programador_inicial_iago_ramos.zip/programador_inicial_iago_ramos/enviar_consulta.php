<?php
$nombre_contacto=$_POST['nombre_contacto'];
$email_contacto=$_POST['email_contacto'];
$consulta=$_POST['consulta'];


$cuerpo_consulta= "Nombre :".$nombre_contacto. "\r\n"."Email: ".$email_contacto."\r\n"."Consulta: ".$consulta;

mail('consultorioramos@consultorioramos.com', 'Mensaje enviado desde consultorioramos.com.ar', $consulta);


$conex= mysqli_connect("localhost", "root", "", "consultorio_ramos") or exit ('no fue posible conectar a la base de datos');
mysqli_query($conex, "INSERT INTO consultas VALUES (DEFAULT, '$nombre_contacto', '$email_contacto', '$consulta')")  ;


header("Location: contacto.php");

mysqli_close($conex);
?>