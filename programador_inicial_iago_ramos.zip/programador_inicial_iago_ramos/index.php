<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/lightbox.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="estilos.css">
    <title>Consultorio Ramos</title>
</head>

<body>
<?php
include ('header.php');
?>
    <section>
        <div class="img_central">
        </div>
        <div class="texto">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, vel, sit numquam, sequi at quo tempore ex
                eligendi beatae vitae eos. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos in
                reprehenderit quae consequatur Lorem ipsum dolor sit amet consectetur adipisicing elit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos in
                reprehenderit quae consequatur Lorem ipsum dolor sit amet consectetur adipisicing elit.Lorem ipsum dolor sit. </p>
        </div>
        <div class="img_home">
        <a href="./img/medico.jpg" data-lightbox="image-1"data-title="Dr. Ricardo Ramos, en la inauguración del consultório, a 25 años atras!"><img src="./img/medico.jpg" alt=""></a>
        </div>
    </section>
    <footer>
    <?php
    include ('footer.php');
    ?>
    </footer>
    <script src="./js/lightbox-plus-jquery.js"></script>
</body>

</html>