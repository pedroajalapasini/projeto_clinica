<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./estilos.css">
    <title>Contacto</title>
</head>
<body>
    <?php
        include ('header.php');
    ?>
    <div  id="contenedor_contacto">
                <h1>Contactanos</h1>
            <form action="enviar_consulta.php" method="post">
                <h3 class="contacto">Nombre: <input type="text" name="nombre_contacto" required></h3>
                <h3 class="contacto">Email: <input type="email" name="email_contacto"  required></h3>
                <h3 class="escriba_consulta">Envie su mensaje: <br>
                <textarea name="consulta" placeholder="Escriba aquí" cols="50" rows="15" required> </textarea></h3>
                <input type="submit" value="Enviar" id="btn_enviar" style="font-size:10pt;">
            </form>
            <div class="turnos">
                <h3  class="contacto"><a href="turnos.php">SOLICITÁ TU TURNO ONLINE.</h3></a>
            </div>
            <?php
    include ('footer.php');
    ?>
</body>
</html>