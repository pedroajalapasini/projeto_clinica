<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/lightbox.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="./estilos.css">
    <title>Institucional</title>
</head>
<body>
<?php
include ('header.php');
?>
<div class="contenedor_inst">
    <div class="text_uno">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias natus dolorem ad consequuntur iusto. Voluptate praesentium cupiditate ullam! Nihil, impedit minima asperiores magnam, veritatis recusandae facilis labore et beatae assumenda fuga aut nesciunt qui numquam.</p>
    </div>
    <div class="text_dos">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo, asperiores quis velit officia quibusdam quas quam culpa fuga minus vitae molestias deserunt, facere odio sit reiciendis omnis cumque fugiat totam. Aliquid doloremque quis quibusdam recusandae.</p>
    </div>
    <div class="img_equipo">
    <a href="img/nosotros.jpg" data-lightbox="image-2"data-title="Nuestro equipo!"><img src="img/nosotros.jpg" alt=""></a>
</div>
</div>
<?php
include ('footer.php');
?>
    <script src="./js/lightbox-plus-jquery.js"></script>
</body>
</html>