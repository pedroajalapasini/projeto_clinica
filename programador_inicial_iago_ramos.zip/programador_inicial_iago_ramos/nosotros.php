<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/lightbox.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="./estilos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <title>Nosotros</title>
</head>
<body>
    <?php
    include ('header.php');
    ?>
    <div class="menu_medico">
                    <ul>
                    <li><a href="nosotros.php?medico=I-R">Iago Ramos</a></li> 
                    <li><a href="nosotros.php?medico=M-P">Marina Pina</a></li>
                    <li><a href="nosotros.php?medico=R-R">Roberto Ramos</a></li>
                    <li><a href="nosotros.php?medico=E-C">Eduardo Cardoso</a></li>
                    <li><a href="nosotros.php?medico=C-F">Catalina Fonseca</a></li>
                    </ul>
    </div>
    <?php
        if (isset($_GET['medico'])){

            switch ($_GET['medico']){
                    case 'I-R':
                        $nombre= 'Iago Ramos';
                        $especialidad='Especialista en Cirugía Plástica Estética y Reparadora.';
                        $titulo='Universidad de Buenos Aires';
                        $n_medico= 'MN: 111111';
                        $img='img/i-r.png';
                        break;
                    case 'M-P':
                        $nombre= 'Marina Pina';
                        $especialidad= 'Ginecologia y Patologia Mamaria';
                        $titulo='Universidad Catolica Argentina';
                        $n_medico= 'MN: 22222';
                        $img='img/m-p.png';
                        break;
                    case 'R-R':
                        $nombre= 'Roberto Ramos';
                        $especialidad= 'Especialista en Ginecología, Obstetricía';
                        $titulo='Universidad de Buenos Aires';
                        $n_medico= 'MN: 00000';
                        $img='img/r-r.png';
                        break;
                    case 'E-C':
                        $nombre= 'Eduardo Cardoso';
                        $especialidad= 'Especialista en Pediatría';
                        $titulo='Universidad de La Plata';
                        $n_medico= 'MN: 33333';
                        $img='img/e-c.png';
                        break;
                    case 'C-F':
                        $nombre= 'Catalina Fonseca';
                        $especialidad= 'Especialista en Nutrición';
                        $titulo='Universidad Nacional de San Martin';
                        $n_medico= 'MN: 44444';
                        $img='img/c-f.png';
                    }
                } 
                    ?>
    <div class="contenedor-principal">
    <div class="img_medico">
    <img src="<?php echo $img ?>" alt="img_medico">
                </div>
                <div class="datos_medico">
            <h2> <?php echo $nombre ?> </h2>  
                <ul>
                <h4 class="medico"><?php echo $especialidad ?></h4>
                <h4 class="n_medico"><?php echo $n_medico ?></h4>
                <h4 class="medico"><?php echo  $titulo ?></h4>
            </ul>
                </div>
    </div>
    <?php
    include ('footer.php');
    ?>
    <script src="./js/lightbox-plus-jquery.js"></script>
</body>
</html>